import type React from 'react'
import { createContext, useContext, useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import * as bcrypt from 'bcryptjs'

interface User {
  id: string
  email: string
  nickname: string
  balance: number
  joinDate: string
  totalOrders: number
  totalSpent: number
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (email: string, password: string, nickname: string) => Promise<boolean>
  logout: () => void
  updateBalance: (amount: number) => Promise<void>
  updateUserStats: (orderAmount: number) => Promise<void>
  addFunds: (amount: number, method: 'card' | 'bank') => Promise<boolean>
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

// Mock users database
interface MockUser {
  id: string
  email: string
  password: string
  nickname: string
  balance: number
  joinDate: string
  totalOrders: number
  totalSpent: number
}

const mockUsers: Record<string, MockUser> = {
  'user@example.com': {
    id: '1',
    email: 'user@example.com',
    password: 'password123',
    nickname: '인스타업러',
    balance: 125000,
    joinDate: '2024-01-15',
    totalOrders: 12,
    totalSpent: 850000
  }
}

// Mock function to simulate API delay
const simulateApiDelay = () => new Promise(resolve => setTimeout(resolve, 1000))

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  // Check for existing session on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('instaup_user')
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)
    console.log('🔐 로그인 시도:', email)

    try {
      // Supabase 연결 테스트
      console.log('📡 Supabase 연결 테스트 중...')

      // Supabase에서 사용자 조회
      const { data: users, error } = await supabase
        .from('users')
        .select('*')
        .eq('email', email)
        .single()

      console.log('📊 Supabase 응답:', { users, error })

      if (error || !users) {
        console.error('❌ Login error:', error)
        alert(`로그인 실패: ${error?.message || '사용자를 찾을 수 없습니다.'}`)
        return false
      }

      // 비밀번호 확인
      console.log('🔑 비밀번호 확인 중...')
      const isPasswordValid = await bcrypt.compare(password, users.password_hash)
      console.log('✅ 비밀번호 검증 결과:', isPasswordValid)

      if (isPasswordValid) {
        console.log('🎉 로그인 성공!')
        const userData: User = {
          id: users.id,
          email: users.email,
          nickname: users.nickname,
          balance: users.balance,
          joinDate: users.created_at.split('T')[0],
          totalOrders: users.total_orders,
          totalSpent: users.total_spent
        }

        setUser(userData)
        localStorage.setItem('instaup_user', JSON.stringify(userData))
        localStorage.setItem('instaup_userId', users.id)
        return true
      }
      return false
    } catch (error) {
      console.error('Login error:', error)
      return false
    } finally {
      setIsLoading(false)
    }
  }

  const register = async (email: string, password: string, nickname: string): Promise<boolean> => {
    setIsLoading(true)

    try {
      await simulateApiDelay()

      // Check if user already exists
      if (mockUsers[email]) {
        return false
      }

      // Create new user
      const newUser: User = {
        id: Date.now().toString(),
        email,
        nickname,
        balance: 10000, // Welcome bonus
        joinDate: new Date().toISOString().split('T')[0],
        totalOrders: 0,
        totalSpent: 0
      }

      // Save to mock database
      mockUsers[email] = {
        ...newUser,
        password
      }

      setUser(newUser)
      localStorage.setItem('instaup_user', JSON.stringify(newUser))
      localStorage.setItem('instaup_token', 'mock-jwt-token')
      return true
    } finally {
      setIsLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('instaup_user')
    localStorage.removeItem('instaup_token')
  }

  const updateBalance = async (amount: number) => {
    if (user) {
      const newBalance = user.balance + amount

      try {
        // Supabase에서 잔액 업데이트
        const { error } = await supabase
          .from('users')
          .update({ balance: newBalance })
          .eq('id', user.id)

        if (!error) {
          const updatedUser = { ...user, balance: newBalance }
          setUser(updatedUser)
          localStorage.setItem('instaup_user', JSON.stringify(updatedUser))
        } else {
          console.error('Balance update error:', error)
        }
      } catch (error) {
        console.error('Balance update error:', error)
      }
    }
  }

  const updateUserStats = async (orderAmount: number) => {
    if (user) {
      const newTotalOrders = user.totalOrders + 1
      const newTotalSpent = user.totalSpent + orderAmount

      try {
        // Supabase에서 사용자 통계 업데이트
        const { error } = await supabase
          .from('users')
          .update({
            total_orders: newTotalOrders,
            total_spent: newTotalSpent
          })
          .eq('id', user.id)

        if (!error) {
          const updatedUser = {
            ...user,
            totalOrders: newTotalOrders,
            totalSpent: newTotalSpent
          }
          setUser(updatedUser)
          localStorage.setItem('instaup_user', JSON.stringify(updatedUser))
        } else {
          console.error('User stats update error:', error)
        }
      } catch (error) {
        console.error('User stats update error:', error)
      }
    }
  }

  const addFunds = async (amount: number, method: 'card' | 'bank'): Promise<boolean> => {
    if (!user) return false

    setIsLoading(true)

    try {
      // 결제 처리 시뮬레이션
      await new Promise(resolve => setTimeout(resolve, 2000))

      // 95% 성공률로 시뮬레이션
      const success = Math.random() > 0.05

      if (success) {
        // 결제 트랜잭션 기록
        const { error: transactionError } = await supabase
          .from('payment_transactions')
          .insert({
            user_id: user.id,
            type: 'charge',
            method: method,
            amount: amount,
            status: 'completed',
            description: `${method === 'card' ? '카드' : '계좌이체'} 충전`
          })

        if (transactionError) {
          console.error('Transaction error:', transactionError)
          return false
        }

        // 잔액 추가
        await updateBalance(amount)
        return true
      }
      throw new Error('결제 처리 중 오류가 발생했습니다.')
    } catch (error) {
      return false
    } finally {
      setIsLoading(false)
    }
  }

  const value: AuthContextType = {
    user,
    login,
    register,
    logout,
    updateBalance,
    updateUserStats,
    addFunds,
    isLoading
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}
