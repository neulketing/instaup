import type React from 'react'
import { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'

interface AddFundsProps {
  onClose: () => void
  onSuccess?: () => void // 충전 성공 시 콜백
}

const AddFunds: React.FC<AddFundsProps> = ({ onClose, onSuccess }) => {
  const { user, addFunds, isLoading } = useAuth()
  const [amount, setAmount] = useState<number>(0)
  const [selectedMethod, setSelectedMethod] = useState<'card' | 'bank'>('card')
  const [isProcessing, setIsProcessing] = useState(false)

  const presetAmounts = [10000, 30000, 50000, 100000, 200000, 500000]

  const handleSubmit = async () => {
    if (amount < 1000) {
      alert('최소 충전 금액은 1,000원입니다.')
      return
    }

    setIsProcessing(true)

    try {
      const success = await addFunds(amount, selectedMethod)

      if (success) {
        alert(`${amount.toLocaleString()}원이 성공적으로 충전되었습니다!`)
        onClose()
        onSuccess?.() // 충전 성공 시 콜백 실행
      } else {
        alert('충전 처리 중 오류가 발생했습니다. 다시 시도해주세요.')
      }
    } catch (error) {
      alert('충전 처리 중 오류가 발생했습니다.')
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-lg">
        <div className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-gray-900">포인트 충전</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 text-3xl w-12 h-12 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
            >
              ×
            </button>
          </div>

          {/* 현재 잔액 */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-6 mb-8">
            <div className="text-center">
              <div className="text-sm text-gray-600 mb-2">현재 보유 포인트</div>
              <div className="text-3xl font-bold text-blue-600">
                {user?.balance.toLocaleString()}원
              </div>
            </div>
          </div>

          {/* 충전 금액 선택 */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">충전 금액</h3>
            <div className="grid grid-cols-3 gap-3 mb-4">
              {presetAmounts.map((presetAmount) => (
                <button
                  key={presetAmount}
                  onClick={() => setAmount(presetAmount)}
                  className={`p-3 rounded-xl border font-medium transition-all ${
                    amount === presetAmount
                      ? 'border-blue-500 bg-blue-50 text-blue-600'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {presetAmount.toLocaleString()}원
                </button>
              ))}
            </div>

            {/* 직접 입력 */}
            <div className="relative">
              <input
                type="number"
                value={amount || ''}
                onChange={(e) => setAmount(Number(e.target.value) || 0)}
                placeholder="직접 입력 (최소 1,000원)"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all"
              />
              <span className="absolute right-4 top-3 text-gray-500">원</span>
            </div>
          </div>

          {/* 결제 방법 선택 */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">결제 방법</h3>
            <div className="space-y-3">
              <button
                onClick={() => setSelectedMethod('card')}
                className={`w-full p-4 rounded-xl border text-left transition-all ${
                  selectedMethod === 'card'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center">
                  <div className={`w-5 h-5 rounded-full border-2 mr-3 ${
                    selectedMethod === 'card'
                      ? 'border-blue-500 bg-blue-500'
                      : 'border-gray-300'
                  }`}>
                    {selectedMethod === 'card' && (
                      <div className="w-2 h-2 bg-white rounded-full m-0.5" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">💳 신용/체크카드</div>
                    <div className="text-sm text-gray-500">즉시 충전</div>
                  </div>
                </div>
              </button>

              <button
                onClick={() => setSelectedMethod('bank')}
                className={`w-full p-4 rounded-xl border text-left transition-all ${
                  selectedMethod === 'bank'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center">
                  <div className={`w-5 h-5 rounded-full border-2 mr-3 ${
                    selectedMethod === 'bank'
                      ? 'border-blue-500 bg-blue-500'
                      : 'border-gray-300'
                  }`}>
                    {selectedMethod === 'bank' && (
                      <div className="w-2 h-2 bg-white rounded-full m-0.5" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">🏦 계좌이체</div>
                    <div className="text-sm text-gray-500">수수료 없음</div>
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* 충전 정보 */}
          {amount > 0 && (
            <div className="bg-gray-50 rounded-2xl p-4 mb-8">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">충전 금액</span>
                <span className="font-medium">{amount.toLocaleString()}원</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">수수료</span>
                <span className="font-medium">무료</span>
              </div>
              <hr className="my-3" />
              <div className="flex justify-between items-center">
                <span className="font-medium">총 결제 금액</span>
                <span className="font-bold text-blue-600 text-lg">
                  {amount.toLocaleString()}원
                </span>
              </div>
            </div>
          )}

          {/* 충전 버튼 */}
          <button
            onClick={handleSubmit}
            disabled={amount < 1000 || isProcessing}
            className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
              amount >= 1000 && !isProcessing
                ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 hover:shadow-lg hover:-translate-y-0.5'
                : 'bg-gray-200 text-gray-500 cursor-not-allowed'
            }`}
          >
            {isProcessing ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                결제 처리 중...
              </div>
            ) : (
              `${amount.toLocaleString()}원 충전하기`
            )}
          </button>

          {/* 안내사항 */}
          <div className="mt-6 text-xs text-gray-500 text-center">
            <p>• 충전된 포인트는 즉시 사용 가능합니다</p>
            <p>• 미사용 포인트는 환불 가능합니다</p>
            <p>• 문의사항은 고객센터로 연락주세요</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AddFunds
