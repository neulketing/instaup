import { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'

interface ReferralSystemProps {
  onClose: () => void
}

interface ReferralStats {
  totalReferred: number
  activeReferrals: number
  totalEarned: number
  pendingRewards: number
  referralCode: string
  referralHistory: ReferralRecord[]
}

interface ReferralRecord {
  id: string
  referredEmail: string
  referredNickname: string
  joinDate: string
  status: 'pending' | 'active' | 'completed'
  rewardEarned: number
  orderCount: number
}

// Mock referral data
const mockReferralData: ReferralStats = {
  totalReferred: 12,
  activeReferrals: 8,
  totalEarned: 240000,
  pendingRewards: 15000,
  referralCode: 'INSTA2024USER',
  referralHistory: [
    {
      id: 'REF001',
      referredEmail: 'friend1@example.com',
      referredNickname: '인플루언서김',
      joinDate: '2024-06-10',
      status: 'completed',
      rewardEarned: 25000,
      orderCount: 5
    },
    {
      id: 'REF002',
      referredEmail: 'friend2@example.com',
      referredNickname: '마케터박',
      joinDate: '2024-06-12',
      status: 'active',
      rewardEarned: 10000,
      orderCount: 2
    },
    {
      id: 'REF003',
      referredEmail: 'friend3@example.com',
      referredNickname: '블로거이',
      joinDate: '2024-06-13',
      status: 'pending',
      rewardEarned: 0,
      orderCount: 0
    }
  ]
}

export default function ReferralSystem({ onClose }: ReferralSystemProps) {
  const { user, updateBalance } = useAuth()
  const [referralStats] = useState<ReferralStats>(mockReferralData)
  const [copiedCode, setCopiedCode] = useState(false)
  const [copiedLink, setCopiedLink] = useState(false)

  const referralLink = `https://instaup.co.kr/signup?ref=${referralStats.referralCode}`

  const copyToClipboard = async (text: string, type: 'code' | 'link') => {
    try {
      await navigator.clipboard.writeText(text)
      if (type === 'code') {
        setCopiedCode(true)
        setTimeout(() => setCopiedCode(false), 2000)
      } else {
        setCopiedLink(true)
        setTimeout(() => setCopiedLink(false), 2000)
      }
    } catch (err) {
      console.error('Failed to copy: ', err)
    }
  }

  const claimRewards = () => {
    if (referralStats.pendingRewards > 0 && user) {
      updateBalance(referralStats.pendingRewards)
      // Create a success notification instead of alert
      if (window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('showNotification', {
          detail: {
            type: 'success',
            title: '보상 지급 완료!',
            message: `${referralStats.pendingRewards.toLocaleString()}원의 추천 보상이 지급되었습니다!`
          }
        }))
      }
    }
  }

  const getStatusBadge = (status: ReferralRecord['status']) => {
    switch (status) {
      case 'pending':
        return (
          <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">
            대기중
          </span>
        )
      case 'active':
        return (
          <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
            활성
          </span>
        )
      case 'completed':
        return (
          <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
            완료
          </span>
        )
      default:
        return null
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-5xl max-h-[90vh] overflow-y-auto">
        <div className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">친구 추천 시스템</h2>
              <p className="text-gray-600">친구를 추천하고 함께 보상을 받으세요!</p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 text-3xl w-12 h-12 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
            >
              ×
            </button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white">
              <h3 className="text-sm font-medium text-blue-100 mb-2">총 추천 인원</h3>
              <p className="text-3xl font-bold">{referralStats.totalReferred}명</p>
            </div>
            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-6 text-white">
              <h3 className="text-sm font-medium text-green-100 mb-2">활성 추천</h3>
              <p className="text-3xl font-bold">{referralStats.activeReferrals}명</p>
            </div>
            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-6 text-white">
              <h3 className="text-sm font-medium text-purple-100 mb-2">총 수익</h3>
              <p className="text-3xl font-bold">{referralStats.totalEarned.toLocaleString()}원</p>
            </div>
            <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-6 text-white">
              <h3 className="text-sm font-medium text-orange-100 mb-2">대기 보상</h3>
              <p className="text-3xl font-bold">{referralStats.pendingRewards.toLocaleString()}원</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column - Referral Tools */}
            <div className="space-y-6">
              {/* Referral Code */}
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200">
                <h3 className="text-xl font-semibold mb-4 text-gray-900">나만의 추천 코드</h3>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="flex-1 bg-white rounded-xl p-4 border">
                    <code className="text-lg font-mono text-purple-600">{referralStats.referralCode}</code>
                  </div>
                  <button
                    onClick={() => copyToClipboard(referralStats.referralCode, 'code')}
                    className="bg-purple-600 text-white px-4 py-3 rounded-xl hover:bg-purple-700 transition-colors"
                  >
                    {copiedCode ? '✓' : '📋'}
                  </button>
                </div>
                <p className="text-sm text-gray-600">
                  친구가 회원가입 시 이 코드를 입력하면 둘 다 10,000원 보너스!
                </p>
              </div>

              {/* Referral Link */}
              <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-200">
                <h3 className="text-xl font-semibold mb-4 text-gray-900">추천 링크 공유</h3>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="flex-1 bg-white rounded-xl p-4 border">
                    <div className="text-sm text-gray-600 break-all">{referralLink}</div>
                  </div>
                  <button
                    onClick={() => copyToClipboard(referralLink, 'link')}
                    className="bg-blue-600 text-white px-4 py-3 rounded-xl hover:bg-blue-700 transition-colors"
                  >
                    {copiedLink ? '✓' : '🔗'}
                  </button>
                </div>
                <div className="flex space-x-3">
                  <button className="bg-green-500 text-white px-4 py-2 rounded-xl hover:bg-green-600 transition-colors text-sm">
                    카카오톡 공유
                  </button>
                  <button className="bg-blue-500 text-white px-4 py-2 rounded-xl hover:bg-blue-600 transition-colors text-sm">
                    페이스북 공유
                  </button>
                  <button className="bg-pink-500 text-white px-4 py-2 rounded-xl hover:bg-pink-600 transition-colors text-sm">
                    인스타그램 공유
                  </button>
                </div>
              </div>

              {/* Rewards Section */}
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
                <h3 className="text-xl font-semibold mb-4 text-gray-900">보상 수령</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">지급 가능한 보상:</span>
                    <span className="text-2xl font-bold text-green-600">
                      {referralStats.pendingRewards.toLocaleString()}원
                    </span>
                  </div>
                  <button
                    onClick={claimRewards}
                    disabled={referralStats.pendingRewards === 0}
                    className="w-full bg-green-600 text-white py-3 rounded-2xl font-semibold hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    보상 지급받기
                  </button>
                </div>
              </div>

              {/* How it Works */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h3 className="text-xl font-semibold mb-4 text-gray-900">추천 시스템 안내</h3>
                <div className="space-y-3 text-sm text-gray-600">
                  <div className="flex items-start space-x-3">
                    <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">1</span>
                    <p>추천 코드나 링크를 친구에게 공유하세요</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">2</span>
                    <p>친구가 가입하면 둘 다 10,000원 보너스 지급</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">3</span>
                    <p>친구가 첫 주문을 완료하면 추가 15,000원 보상</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">4</span>
                    <p>친구가 활동할수록 지속적인 보상 지급</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Referral History */}
            <div>
              <div className="bg-white rounded-2xl border border-gray-200 p-6">
                <h3 className="text-xl font-semibold mb-6 text-gray-900">추천 내역</h3>

                <div className="space-y-4">
                  {referralStats.referralHistory.map((referral) => (
                    <div
                      key={referral.id}
                      className="border border-gray-200 rounded-2xl p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-gray-900">{referral.referredNickname}</h4>
                          <p className="text-sm text-gray-500">{referral.referredEmail}</p>
                          <p className="text-xs text-gray-400">가입일: {referral.joinDate}</p>
                        </div>
                        <div className="text-right">
                          {getStatusBadge(referral.status)}
                          <p className="text-sm text-green-600 font-semibold mt-1">
                            +{referral.rewardEarned.toLocaleString()}원
                          </p>
                        </div>
                      </div>

                      <div className="flex justify-between text-sm text-gray-600">
                        <span>주문 횟수: {referral.orderCount}회</span>
                        <span>추천 ID: {referral.id}</span>
                      </div>

                      {referral.status === 'pending' && (
                        <div className="mt-3 p-3 bg-yellow-50 rounded-xl">
                          <p className="text-sm text-yellow-700">
                            ⏳ 친구가 첫 주문을 완료하면 보상이 지급됩니다
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {referralStats.referralHistory.length === 0 && (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">👥</div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">
                      아직 추천 내역이 없습니다
                    </h4>
                    <p className="text-gray-600">
                      친구들을 초대하고 함께 보상을 받아보세요!
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
