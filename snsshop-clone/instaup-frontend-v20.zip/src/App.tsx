import React, { useState, useRef } from 'react'
import { AuthProvider } from './contexts/AuthContext'
import { AdminProvider, useAdmin } from './contexts/AdminContext'
import { OrderProvider } from './contexts/OrderContext'
import NotificationSystem, { useNotifications } from './components/NotificationSystem'
import Header from './components/Header'
import Hero from './components/Hero'
import PlatformGrid from './components/PlatformGrid'
import PriceCalculator from './components/PriceCalculator'
import HowToUse from './components/HowToUse'
import Footer from './components/Footer'
import LoginModal from './components/LoginModal'
import SignupModal from './components/SignupModal'
import FloatingKakao from './components/FloatingKakao'
import EnhancedOrderForm from './components/EnhancedOrderForm'
import PlatformOrderForm from './components/PlatformOrderForm'
import NaverServiceForm from './components/NaverServiceForm'
import UserDashboard from './components/UserDashboard'
import AdminLogin from './components/AdminLogin'
import AdminPanel from './components/AdminPanel'
import AdminRoute from './components/AdminRoute'
import OrderTracker from './components/OrderTracker'
import PaymentModal from './components/PaymentModal'
import OrderDashboard from './components/OrderDashboard'
import AddFunds from './components/AddFunds'
import { useRouter } from './hooks/useRouter'

// Create a separate component to use admin context
function AppContent() {
  const [showLogin, setShowLogin] = useState(false)
  const [showSignup, setShowSignup] = useState(false)
  const [showOrderForm, setShowOrderForm] = useState(false)
  const [showDashboard, setShowDashboard] = useState(false)
  const [showAdminLogin, setShowAdminLogin] = useState(false)
  const [showAdminPanel, setShowAdminPanel] = useState(false)
  const [showPlatformOrderForm, setShowPlatformOrderForm] = useState(false)
  const [showNaverServiceForm, setShowNaverServiceForm] = useState(false)
  const [showOrderDashboard, setShowOrderDashboard] = useState(false)
  const [showAddFunds, setShowAddFunds] = useState(false)
  const [selectedPlatform, setSelectedPlatform] = useState('')

  const { isAdmin } = useAdmin()
  const { notifications, removeNotification, showSuccess, showInfo } = useNotifications()
  const hasShownWelcome = useRef(false)

  // Show welcome notification on mount
  React.useEffect(() => {
    if (!hasShownWelcome.current) {
      showInfo('INSTAUP에 오신 것을 환영합니다!', '실제 한국인 팔로워로 SNS를 성장시키세요', 7000)
      hasShownWelcome.current = true
    }
  }, [showInfo])

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        onLoginClick={() => setShowLogin(true)}
        onSignupClick={() => setShowSignup(true)}
        onDashboardClick={() => setShowDashboard(true)}
        onOrdersClick={() => setShowOrderDashboard(true)}
      />
      <Hero onOrderClick={() => setShowOrderForm(true)} />
      <PlatformGrid
        onOrderClick={() => setShowOrderForm(true)}
        onPlatformOrderClick={(platform: string) => {
          if (platform === '네이버') {
            setShowNaverServiceForm(true)
          } else {
            setSelectedPlatform(platform)
            setShowPlatformOrderForm(true)
          }
        }}
      />

      {/* Price Calculator Section */}
      <div className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <PriceCalculator onOrderClick={() => setShowOrderForm(true)} />
        </div>
      </div>

      <HowToUse />
      <Footer />
      <FloatingKakao />

      {/* Admin Button */}
      {!isAdmin && (
        <button
          onClick={() => setShowAdminLogin(true)}
          className="fixed bottom-6 left-6 bg-gray-800 text-white p-3 rounded-full hover:bg-gray-900 transition-colors z-40"
          title="관리자 로그인"
        >
          ⚙️
        </button>
      )}

      {isAdmin && (
        <button
          onClick={() => setShowAdminPanel(true)}
          className="fixed bottom-6 left-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-3 rounded-full hover:from-purple-700 hover:to-pink-700 transition-colors z-40 shadow-lg"
        >
          <span className="mr-2">⚙️</span>
          <span className="hidden sm:inline">관리자</span>
        </button>
      )}

      {showLogin && (
        <LoginModal
          onClose={() => setShowLogin(false)}
          onSignupClick={() => {
            setShowLogin(false)
            setShowSignup(true)
          }}
        />
      )}

      {showSignup && (
        <SignupModal
          onClose={() => setShowSignup(false)}
          onLoginClick={() => {
            setShowSignup(false)
            setShowLogin(true)
          }}
        />
      )}

      {showOrderForm && (
        <EnhancedOrderForm
          onClose={() => setShowOrderForm(false)}
          onLoginRequired={() => {
            setShowOrderForm(false)
            setShowLogin(true)
          }}
          onInsufficientFunds={() => {
            setShowOrderForm(false)
            setShowAddFunds(true)
          }}
        />
      )}

      {showDashboard && (
        <UserDashboard
          onClose={() => setShowDashboard(false)}
          onAddFunds={() => {
            setShowDashboard(false)
            setShowAddFunds(true)
          }}
        />
      )}

      {showAdminLogin && (
        <AdminLogin
          onClose={() => setShowAdminLogin(false)}
          onSuccess={() => setShowAdminPanel(true)}
        />
      )}

      {showAdminPanel && (
        <AdminPanel onClose={() => setShowAdminPanel(false)} />
      )}

      {showPlatformOrderForm && selectedPlatform && (
        <PlatformOrderForm
          onClose={() => {
            setShowPlatformOrderForm(false)
            setSelectedPlatform('')
          }}
          selectedPlatform={selectedPlatform}
        />
      )}

      {showNaverServiceForm && (
        <NaverServiceForm
          onClose={() => setShowNaverServiceForm(false)}
        />
      )}

      {showOrderDashboard && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-7xl max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">주문 관리</h2>
              <button
                onClick={() => setShowOrderDashboard(false)}
                className="text-gray-400 hover:text-gray-600 text-3xl w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
              >
                ×
              </button>
            </div>
            <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
              <OrderDashboard />
            </div>
          </div>
        </div>
      )}

      {showAddFunds && (
        <AddFunds
          onClose={() => setShowAddFunds(false)}
          onSuccess={() => {
            // 충전 완료 후 주문 페이지로 복귀
            setShowOrderForm(true)
          }}
        />
      )}

      {/* Notification System */}
      <NotificationSystem
        notifications={notifications}
        removeNotification={removeNotification}
      />
    </div>
  )
}

function App() {
  return (
    <AuthProvider>
      <OrderProvider>
        <AdminProvider>
          <AppContent />
        </AdminProvider>
      </OrderProvider>
    </AuthProvider>
  )
}

export default App
