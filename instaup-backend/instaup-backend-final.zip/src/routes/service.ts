import { Router } from 'express'

const router = Router()

// Mock service data
const services = [
  {
    id: 'instagram-followers-kr',
    name: '인스타그램 한국인 팔로워',
    platform: 'Instagram',
    price: 150,
    minQuantity: 100,
    maxQuantity: 10000,
    description: '100% 실제 한국인 계정으로 안전하게 팔로워를 늘려드립니다'
  }
]

router.get('/', (req, res) => {
  res.json({
    success: true,
    data: services,
    message: '서비스 목록 조회 성공'
  })
})

router.get('/:id', (req, res) => {
  const service = services.find(s => s.id === req.params.id)

  if (!service) {
    return res.status(404).json({
      success: false,
      error: '서비스를 찾을 수 없습니다.'
    })
  }

  res.json({
    success: true,
    data: service,
    message: '서비스 상세 조회 성공'
  })
})

export default router
