import { Router } from 'express'
import { authMiddleware } from '../middleware/auth'

const router = Router()
router.use(authMiddleware)

router.post('/kakao/ready', async (req, res) => {
  try {
    // 카카오페이 결제 준비 로직 (나중에 구현)
    res.json({
      success: true,
      message: '카카오페이 결제 API (준비중)'
    })
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message
    })
  }
})

router.post('/toss/confirm', async (req, res) => {
  try {
    // 토스페이 결제 승인 로직 (나중에 구현)
    res.json({
      success: true,
      message: '토스페이 결제 API (준비중)'
    })
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message
    })
  }
})

export default router
