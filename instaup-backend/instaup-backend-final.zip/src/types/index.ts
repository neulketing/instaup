import type { Request } from 'express'

// Core user types
export interface UserProfile {
  id: string
  email: string
  nickname: string
  phone?: string
  birthDate?: Date
  isVerified: boolean
  balance: number
  totalSpent: number
  referralCode: string
  referredBy?: string
  createdAt: Date
  updatedAt: Date
}

export interface CreateUserDto {
  email: string
  password: string
  nickname: string
  phone?: string
  birthDate?: string
  referralCode?: string
}

export interface LoginDto {
  email: string
  password: string
}

// Service types
export interface ServiceConfig {
  id: string
  name: string
  platform: string
  category: string
  description: string
  price: number
  minQuantity: number
  maxQuantity: number
  discountRate: number
  estimatedTime: string
  qualityLevel: 'standard' | 'premium' | 'ultimate'
  features: string[]
  isActive: boolean
  isPopular?: boolean
  isNew?: boolean
  bulkDiscounts: BulkDiscount[]
}

export interface BulkDiscount {
  minQuantity: number
  discountPercent: number
}

// Order types
export interface CreateOrderDto {
  serviceId: string
  quantity: number
  targetUrl: string
  notes?: string
}

export enum OrderStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled',
  REFUNDED = 'refunded'
}

// Payment types
export enum PaymentMethod {
  KAKAOPAY = 'kakaopay',
  TOSSPAY = 'tosspay',
  CREDIT_CARD = 'credit_card',
  BANK_TRANSFER = 'bank_transfer',
  BALANCE = 'balance'
}

export enum PaymentStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  CANCELLED = 'cancelled',
  FAILED = 'failed',
  REFUNDED = 'refunded'
}

// API Response types
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  message?: string
  error?: string
  errors?: Record<string, string[]>
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  totalPages: number
}

// Request extensions
export interface AuthenticatedRequest extends Request {
  user?: UserProfile
}
EOF  
cd /home/project && cat > instaup-backend/src/types/index.ts << 'EOF'
import type { Request } from 'express'

// Core user types
export interface UserProfile {
  id: string
  email: string
  nickname: string
  phone?: string
  birthDate?: Date
  isVerified: boolean
  balance: number
  totalSpent: number
  referralCode: string
  referredBy?: string
  createdAt: Date
  updatedAt: Date
}

export interface CreateUserDto {
  email: string
  password: string
  nickname: string
  phone?: string
  birthDate?: string
  referralCode?: string
}

export interface LoginDto {
  email: string
  password: string
}

// Service types
export interface ServiceConfig {
  id: string
  name: string
  platform: string
  category: string
  description: string
  price: number
  minQuantity: number
  maxQuantity: number
  discountRate: number
  estimatedTime: string
  qualityLevel: 'standard' | 'premium' | 'ultimate'
  features: string[]
  isActive: boolean
  isPopular?: boolean
  isNew?: boolean
  bulkDiscounts: BulkDiscount[]
}

export interface BulkDiscount {
  minQuantity: number
  discountPercent: number
}

// Order types
export interface CreateOrderDto {
  serviceId: string
  quantity: number
  targetUrl: string
  notes?: string
}

export enum OrderStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled',
  REFUNDED = 'refunded'
}

// Payment types
export enum PaymentMethod {
  KAKAOPAY = 'kakaopay',
  TOSSPAY = 'tosspay',
  CREDIT_CARD = 'credit_card',
  BANK_TRANSFER = 'bank_transfer',
  BALANCE = 'balance'
}

export enum PaymentStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  CANCELLED = 'cancelled',
  FAILED = 'failed',
  REFUNDED = 'refunded'
}

// API Response types
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  message?: string
  error?: string
  errors?: Record<string, string[]>
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  totalPages: number
}

// Request extensions
export interface AuthenticatedRequest extends Request {
  user?: UserProfile
}
