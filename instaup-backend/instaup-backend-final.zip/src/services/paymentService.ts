import axios from 'axios'
import { logger } from '../utils/logger'

export interface PaymentRequest {
  orderId: string
  amount: number
  orderName: string
  customerName: string
  customerEmail?: string
  successUrl: string
  failUrl: string
  cancelUrl: string
}

export interface PaymentResponse {
  success: boolean
  paymentKey?: string
  orderId: string
  amount: number
  approvalUrl?: string
  failReason?: string
}

// KakaoPay Implementation
export class KakaoPayService {
  private readonly baseUrl: string
  private readonly cid: string
  private readonly secretKey: string

  constructor() {
    this.baseUrl = process.env.KAKAO_PAY_API_URL || 'https://kapi.kakao.com'
    this.cid = process.env.KAKAO_PAY_CID || ''
    this.secretKey = process.env.KAKAO_PAY_SECRET_KEY || ''
  }

  async requestPayment(request: PaymentRequest): Promise<PaymentResponse> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/v1/payment/ready`,
        {
          cid: this.cid,
          partner_order_id: request.orderId,
          partner_user_id: request.customerEmail || 'guest',
          item_name: request.orderName,
          quantity: 1,
          total_amount: request.amount,
          tax_free_amount: 0,
          approval_url: request.successUrl,
          cancel_url: request.cancelUrl,
          fail_url: request.failUrl
        },
        {
          headers: {
            'Authorization': `KakaoAK ${this.secretKey}`,
            'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
          }
        }
      )

      return {
        success: true,
        paymentKey: response.data.tid,
        orderId: request.orderId,
        amount: request.amount,
        approvalUrl: response.data.next_redirect_pc_url
      }
    } catch (error: any) {
      logger.error('KakaoPay payment request failed:', error.response?.data || error.message)
      return {
        success: false,
        orderId: request.orderId,
        amount: request.amount,
        failReason: error.response?.data?.msg || error.message
      }
    }
  }

  async approvePayment(tid: string, pgToken: string, orderId: string): Promise<any> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/v1/payment/approve`,
        {
          cid: this.cid,
          tid: tid,
          partner_order_id: orderId,
          partner_user_id: 'guest',
          pg_token: pgToken
        },
        {
          headers: {
            'Authorization': `KakaoAK ${this.secretKey}`,
            'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
          }
        }
      )

      return response.data
    } catch (error: any) {
      logger.error('KakaoPay payment approval failed:', error.response?.data || error.message)
      throw error
    }
  }
}

// TossPay Implementation
export class TossPayService {
  private readonly baseUrl: string
  private readonly clientKey: string
  private readonly secretKey: string

  constructor() {
    this.baseUrl = process.env.TOSS_PAY_API_URL || 'https://api.tosspayments.com'
    this.clientKey = process.env.TOSS_PAY_CLIENT_KEY || ''
    this.secretKey = process.env.TOSS_PAY_SECRET_KEY || ''
  }

  async requestPayment(request: PaymentRequest): Promise<PaymentResponse> {
    try {
      // TossPay uses client-side integration, so we return the necessary data
      return {
        success: true,
        orderId: request.orderId,
        amount: request.amount,
        approvalUrl: `${this.baseUrl}/v1/payments`
      }
    } catch (error: any) {
      logger.error('TossPay payment request failed:', error.message)
      return {
        success: false,
        orderId: request.orderId,
        amount: request.amount,
        failReason: error.message
      }
    }
  }

  async confirmPayment(paymentKey: string, orderId: string, amount: number): Promise<any> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/v1/payments/confirm`,
        {
          paymentKey,
          orderId,
          amount
        },
        {
          headers: {
            'Authorization': `Basic ${Buffer.from(`${this.secretKey}:`).toString('base64')}`,
            'Content-Type': 'application/json'
          }
        }
      )

      return response.data
    } catch (error: any) {
      logger.error('TossPay payment confirmation failed:', error.response?.data || error.message)
      throw error
    }
  }

  async cancelPayment(paymentKey: string, cancelReason: string): Promise<any> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/v1/payments/${paymentKey}/cancel`,
        {
          cancelReason
        },
        {
          headers: {
            'Authorization': `Basic ${Buffer.from(`${this.secretKey}:`).toString('base64')}`,
            'Content-Type': 'application/json'
          }
        }
      )

      return response.data
    } catch (error: any) {
      logger.error('TossPay payment cancellation failed:', error.response?.data || error.message)
      throw error
    }
  }
}

// Payment Factory
export class PaymentServiceFactory {
  static createService(method: 'KAKAOPAY' | 'TOSSPAY') {
    switch (method) {
      case 'KAKAOPAY':
        return new KakaoPayService()
      case 'TOSSPAY':
        return new TossPayService()
      default:
        throw new Error(`Unsupported payment method: ${method}`)
    }
  }
}
