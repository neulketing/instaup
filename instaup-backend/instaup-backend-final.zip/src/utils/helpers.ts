import { prisma } from '../config/database'

export const generateReferralCode = async (): Promise<string> => {
  let code: string
  let isUnique = false

  while (!isUnique) {
    // Generate 8-character code with uppercase letters and numbers
    code = Math.random().toString(36).substring(2, 10).toUpperCase()
    
    // Check if code already exists
    const existingUser = await prisma.user.findUnique({
      where: { referralCode: code }
    })
    
    if (!existingUser) {
      isUnique = true
      return code
    }
  }

  return 'INSTAUP' // fallback
}

export const validateUrl = (url: string): boolean => {
  try {
    new URL(url)
    return true
  } catch {
    return false
  }
}

export const formatKoreanCurrency = (amount: number): string => {
  return amount.toLocaleString('ko-KR') + '원'
}

export const generateOrderId = (): string => {
  const timestamp = Date.now().toString(36)
  const random = Math.random().toString(36).substring(2, 8)
  return `ORD_${timestamp}_${random}`.toUpperCase()
}

export const calculateBulkDiscount = (quantity: number, bulkDiscounts: Array<{ minQuantity: number; discountPercent: number }>): number => {
  let maxDiscount = 0
  
  for (const discount of bulkDiscounts) {
    if (quantity >= discount.minQuantity) {
      maxDiscount = Math.max(maxDiscount, discount.discountPercent)
    }
  }
  
  return maxDiscount
}

export const sanitizeInput = (input: string): string => {
  return input.trim().replace(/[<>]/g, '')
}

export const isValidKoreanPhone = (phone: string): boolean => {
  const phoneRegex = /^01([0|1|6|7|8|9])-?([0-9]{3,4})-?([0-9]{4})$/
  return phoneRegex.test(phone)
}

export const sleep = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms))
}
EOF  
cd /home/project && cat > instaup-backend/src/utils/helpers.ts << 'EOF'
import { prisma } from '../config/database'

export const generateReferralCode = async (): Promise<string> => {
  let code: string
  let isUnique = false

  while (!isUnique) {
    // Generate 8-character code with uppercase letters and numbers
    code = Math.random().toString(36).substring(2, 10).toUpperCase()
    
    // Check if code already exists
    const existingUser = await prisma.user.findUnique({
      where: { referralCode: code }
    })
    
    if (!existingUser) {
      isUnique = true
      return code
    }
  }

  return 'INSTAUP' // fallback
}

export const validateUrl = (url: string): boolean => {
  try {
    new URL(url)
    return true
  } catch {
    return false
  }
}

export const formatKoreanCurrency = (amount: number): string => {
  return amount.toLocaleString('ko-KR') + '원'
}

export const generateOrderId = (): string => {
  const timestamp = Date.now().toString(36)
  const random = Math.random().toString(36).substring(2, 8)
  return `ORD_${timestamp}_${random}`.toUpperCase()
}

export const calculateBulkDiscount = (quantity: number, bulkDiscounts: Array<{ minQuantity: number; discountPercent: number }>): number => {
  let maxDiscount = 0
  
  for (const discount of bulkDiscounts) {
    if (quantity >= discount.minQuantity) {
      maxDiscount = Math.max(maxDiscount, discount.discountPercent)
    }
  }
  
  return maxDiscount
}

export const sanitizeInput = (input: string): string => {
  return input.trim().replace(/[<>]/g, '')
}

export const isValidKoreanPhone = (phone: string): boolean => {
  const phoneRegex = /^01([0|1|6|7|8|9])-?([0-9]{3,4})-?([0-9]{4})$/
  return phoneRegex.test(phone)
}

export const sleep = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms))
}
