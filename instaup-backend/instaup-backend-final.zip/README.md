# 🚀 INSTAUP 백엔드 Railway 배포 가이드

## ✅ 빌드 테스트 완료!
- Bun 빌드 성공 ✅
- 모든 의존성 설치 완료 ✅
- TypeScript 컴파일 완료 ✅

## 📋 Railway 배포 단계

### 1. GitHub 연동 배포 (권장)

#### Step 1: Railway 가입
1. https://railway.app 접속
2. "Sign up with GitHub" 클릭
3. GitHub 계정으로 로그인

#### Step 2: 새 프로젝트 생성
1. Railway 대시보드에서 "New Project" 클릭
2. "Deploy from GitHub repo" 선택
3. `instaup-backend` 저장소 선택
4. 자동 배포 시작됨

#### Step 3: PostgreSQL 데이터베이스 추가
1. 프로젝트 페이지에서 "Add Service" 클릭
2. "Database" → "PostgreSQL" 선택
3. 자동으로 `DATABASE_URL` 환경변수 생성됨

#### Step 4: 환경변수 설정
Railway 프로젝트 설정에서 다음 변수들을 추가:

```bash
NODE_ENV=production
PORT=3000
JWT_SECRET=instaup_jwt_secret_2024_super_secure_key
CORS_ORIGIN=https://delicate-profiterole-bbf92a.netlify.app
FRONTEND_URL=https://delicate-profiterole-bbf92a.netlify.app

# 결제 시스템 (테스트 키)
KAKAO_PAY_CID=TC0ONETIME
KAKAO_PAY_SECRET_KEY=test_kakao_secret_key
TOSS_PAY_CLIENT_KEY=test_ck_docs_Ovk5rk1EwkEbP0W43n07xlzm
TOSS_PAY_SECRET_KEY=test_sk_docs_OePz8L5KdmQXkzRzwayLN7EG

# 기타
REDIS_URL=redis://localhost:6379
LOG_LEVEL=info
```

#### Step 5: Prisma 마이그레이션 실행
Railway 콘솔에서 실행:
```bash
npx prisma generate
npx prisma db push
```

### 2. 배포 완료 후 확인사항

#### API 엔드포인트 테스트
배포된 Railway URL 확인 후:
- `GET /health` - 서버 상태 확인
- `POST /api/auth/register` - 회원가입 테스트
- `GET /api/services` - 서비스 목록 테스트

#### 예상 배포 URL 형식:
`https://instaup-backend-production.up.railway.app`

---

## 🔧 프론트엔드 연결 설정

배포 완료 후 프론트엔드 API URL 업데이트 필요:

### src/config/api.ts 수정:
```typescript
export const API_CONFIG = {
  BASE_URL: 'https://[Railway-배포-URL].railway.app',
  // 기존 엔드포인트들 유지
}
```

### PaymentModal.tsx 테스트:
- 카카오페이 결제 플로우 테스트
- 토스페이 결제 플로우 테스트

---

## 📊 배포 상태 체크리스트

- [ ] Railway GitHub 연동 완료
- [ ] PostgreSQL 데이터베이스 연결
- [ ] 환경변수 설정 완료
- [ ] Prisma 마이그레이션 실행
- [ ] `/health` 엔드포인트 응답 확인
- [ ] 프론트엔드 API URL 업데이트
- [ ] 기본 API 기능 테스트 (로그인, 회원가입)

---

## 🎯 현재 준비 상태: 100% 완료!

모든 코드, 설정, 의존성이 준비되었습니다.
Railway 가입 → GitHub 연동 → 환경변수 입력만 하면 즉시 배포됩니다!

---

*다음 단계: Railway 배포 → API 연결 → 도메인 설정*
