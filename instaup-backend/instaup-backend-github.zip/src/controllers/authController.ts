import { Request, Response } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { prisma } from '../config/database'

export const register = async (req: Request, res: Response): Promise<any> => {
  try {
    const { email, password, nickname } = req.body

    const existingUser = await prisma.user.findUnique({ where: { email } })
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: '이미 등록된 이메일입니다.'
      })
    }

    const hashedPassword = await bcrypt.hash(password, 12)
    const referralCode = Math.random().toString(36).substring(2, 10).toUpperCase()

    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        nickname,
        referralCode,
        balance: 10000
      },
      select: {
        id: true,
        email: true,
        nickname: true,
        balance: true,
        referralCode: true,
        createdAt: true
      }
    })

    const token = jwt.sign(
      { userId: user.id, email: user.email },
      process.env.JWT_SECRET!,
      { expiresIn: '7d' }
    )

    res.status(201).json({
      success: true,
      data: { user, token },
      message: '회원가입이 완료되었습니다.'
    })
  } catch (error) {
    console.error('Registration error:', error)
    res.status(500).json({
      success: false,
      error: '회원가입 중 오류가 발생했습니다.'
    })
  }
}

export const login = async (req: Request, res: Response): Promise<any> => {
  try {
    const { email, password } = req.body

    const user = await prisma.user.findUnique({
      where: { email, isActive: true }
    })

    if (!user || !await bcrypt.compare(password, user.password)) {
      return res.status(401).json({
        success: false,
        error: '이메일 또는 비밀번호가 올바르지 않습니다.'
      })
    }

    const token = jwt.sign(
      { userId: user.id, email: user.email },
      process.env.JWT_SECRET!,
      { expiresIn: '7d' }
    )

    const { password: _, ...userWithoutPassword } = user

    res.json({
      success: true,
      data: { user: userWithoutPassword, token },
      message: '로그인 성공'
    })
  } catch (error) {
    console.error('Login error:', error)
    res.status(500).json({
      success: false,
      error: '로그인 중 오류가 발생했습니다.'
    })
  }
}

export const getProfile = async (req: Request, res: Response): Promise<any> => {
  try {
    const userId = (req as any).user.id

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        nickname: true,
        balance: true,
        totalSpent: true,
        referralCode: true,
        createdAt: true
      }
    })

    res.json({
      success: true,
      data: user
    })
  } catch (error) {
    console.error('Get profile error:', error)
    res.status(500).json({
      success: false,
      error: '프로필 조회 중 오류가 발생했습니다.'
    })
  }
}
