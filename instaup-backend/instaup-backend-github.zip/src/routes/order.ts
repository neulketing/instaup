import { Router } from 'express'
import { authMiddleware } from '../middleware/auth'

const router = Router()
router.use(authMiddleware)

router.post('/', async (req, res) => {
  res.json({
    success: true,
    message: '주문 생성 API (준비중)'
  })
})

router.get('/', async (req, res) => {
  res.json({
    success: true,
    data: [],
    message: '주문 내역 조회 API (준비중)'
  })
})

export default router
